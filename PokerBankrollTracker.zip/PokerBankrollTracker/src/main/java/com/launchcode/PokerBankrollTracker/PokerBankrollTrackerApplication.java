package com.launchcode.PokerBankrollTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokerBankrollTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PokerBankrollTrackerApplication.class, args);
	}

}

